#!/usr/bin/env bash

$XGETTEXT `find . -name '*.py'` -o $podir/kdeconnect-nautilus-extension.pot
