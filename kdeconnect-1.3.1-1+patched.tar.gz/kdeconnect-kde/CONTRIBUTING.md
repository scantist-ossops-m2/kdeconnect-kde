This information is provided for Github users who may wonder why issues are disabled.

To file bugs, use the [kde bugtracker](https://bugs.kde.org/describecomponents.cgi?product=kdeconnect).

To request features, join the discussion on the [mailing list](https://mail.kde.org/mailman/listinfo/kdeconnect).
