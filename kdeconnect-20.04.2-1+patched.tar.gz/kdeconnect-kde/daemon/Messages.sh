#!/usr/bin/env bash

$XGETTEXT `find . -name '*.cpp'` -o $podir/kdeconnect-kded.pot
